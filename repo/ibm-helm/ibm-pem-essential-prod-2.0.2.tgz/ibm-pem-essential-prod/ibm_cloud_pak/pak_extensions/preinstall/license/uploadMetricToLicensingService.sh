#!/bin/bash

# Step 1: Get the URL from the kubectl command
url=$(kubectl get route ibm-licensing-service-instance -n ibm-common-services -o jsonpath='{.spec.host}' | awk '{print "https://"$1}')

# Step 2: Get the token from the kubectl command
token=$(kubectl get secret ibm-licensing-upload-token -n ibm-common-services -o jsonpath='{.data.token-upload}' | base64 --decode)

# Step 3: Form the full URL for the endpoint
endpoint="$url/v2/metric_upload?token=$token"

# Step 4: Prepare the first JSON data (with first set of form data)
json_data_1=$(cat <<EOF
{
    "cloudpakId": "",
    "cloudpakMetric": "",
    "cloudpakName": "",
    "productCloudpakRatio": "",
    "metricValue": 1,
    "productId": "ceced8c86aad40329dac5491c44cd843",
    "productMetric": "RESOURCE_VALUE_UNIT",
    "productName": "IBM Sterling Partner Engagement Manager Essential Container Edition"
}
EOF
)

# Step 5: Prepare the second JSON data (with second set of form data)
json_data_2=$(cat <<EOF
{
    "cloudpakId": "",
    "cloudpakMetric": "",
    "cloudpakName": "",
    "productCloudpakRatio": "",
    "metricValue": 1,
    "productId": "2a036dcdaa8f499f9f7485c93efdb030",
    "productMetric": "RESOURCE_VALUE_UNIT",
    "productName": "IBM Sterling Partner Engagement Manager Essential for Non-Prod Container Edition"
}
EOF
)

# Step 6: Make the first POST request using curl and capture both response body and HTTP status code
response_1=$(curl -k -s -w "%{http_code}" -X POST "$endpoint" \
    -H "Content-Type: application/json" \
    -d "$json_data_1")

# Extract the HTTP status code (last 3 digits of the response)
http_code_1="${response_1: -3}"

# Output the HTTP status code and the response body for the first API call
echo "API Response for Uploading RESOURCE_VALUE_UNIT Metric for Prod Env: $http_code_1"

# Step 7: Make the second POST request using curl and capture both response body and HTTP status code
response_2=$(curl -k -s -w "%{http_code}" -X POST "$endpoint" \
    -H "Content-Type: application/json" \
    -d "$json_data_2")

# Extract the HTTP status code (last 3 digits of the response)
http_code_2="${response_2: -3}"

# Output the HTTP status code and the response body for the second API call
echo "API Response for Uploading RESOURCE_VALUE_UNIT Metric for Non-Prod Env: $http_code_2"