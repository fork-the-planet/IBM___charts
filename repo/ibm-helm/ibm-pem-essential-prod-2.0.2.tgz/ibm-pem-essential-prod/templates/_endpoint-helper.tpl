# (C) Copyright 2019-2026 Precisely Incorporated. All rights reserved.

{{- define "pem.pemUrl" -}}

  {{- $protocol := "https" -}}
  {{- $url := "" -}}

  {{/* 1. If hostname is provided (OpenShift Route / Ingress style) */}}
  {{- if .Values.pem.hostname }}
      {{- $url = printf "%s://%s" $protocol .Values.pem.hostname -}}
  {{- end }}

  {{- $url -}}

{{- end }}

{{- define "pem.pem2Url" -}}

  {{- $protocol := "https" -}}
  {{- $url := "" -}}

  {{/* 1. If hostname is provided (OpenShift Route / Ingress style) */}}
  {{- if .Values.pem2.hostname }}
      {{- $url = printf "%s://%s" $protocol .Values.pem2.hostname -}}
  {{- end }}

  {{- $url -}}

{{- end }}


{{- define "pem.identityUrl" -}}

  {{- $svc := .Values.identityService -}}
  {{- $protocol := ternary "https" "http" $svc.application.server.ssl.enabled -}}
  {{- $url := "" -}}

  {{/* 1. INGRESS ENABLED */}}
  {{- if $svc.ingress.enabled }}
      {{- $url = printf "%s://%s" $protocol $svc.ingress.host -}}

  {{/* 2. NODEPORT */}}
  {{- else if and (eq $svc.service.type "NodePort") $svc.service.externalIP }}
      {{- $url = printf "%s://%s:%v" $protocol $svc.service.externalIP $svc.service.nodePort -}}

  {{/* 3a. LOADBALANCER with externalIP */}}
  {{- else if and (eq $svc.service.type "LoadBalancer") $svc.service.externalIP }}
      {{- $url = printf "%s://%s:%v" $protocol $svc.service.externalIP $svc.service.externalPort -}}

  {{/* 3b. LOADBALANCER fallback loadBalancerIP */}}
  {{- else if eq $svc.service.type "LoadBalancer" }}
      {{- $url = printf "%s://%s:%v" $protocol $svc.service.loadBalancerIP $svc.service.externalPort -}}
  {{- end }}

  {{- $url -}}

{{- end }}

{{- define "pem.gatewayUrl" -}}

  {{- $protocol := "https" -}}
  {{- $url := "" -}}

  {{/* 1. If hostname is provided (OpenShift Route / Ingress style) */}}
  {{- if .Values.gateway.hostname }}
      {{- $url = printf "%s://%s" $protocol .Values.gateway.hostname -}}
  {{- end }}
  {{- $url -}}

{{- end }}