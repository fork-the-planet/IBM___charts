{{- /*
Chart specific config file for SCH (Shared Configurable Helpers)
_sch-chart-config.tpl is a config file for the chart to specify additional
values and/or override values defined in the sch/_config.tpl file.

*/ -}}

{{- /*
"sch.chart.config.values" contains the chart specific values used to override or provide
additional configuration values used by the Shared Configurable Helpers.
*/ -}}
{{- define "ibm-sccm.sch.chart.config.values" -}}

{{- $runAsUser := .Values.storageSecurity.runAsUser -}}
{{- if .Values.ccArgs.appUserUID }} 
  {{- $runAsUser = .Values.ccArgs.appUserUID }}  
{{- end }}

sch:
  chart:
    appName: "ibm-sccm"
    components:
      ibmDefaultPullSecret:
        name: "ibm-entitlement-key"
    metering:
    {{- if eq (toString .Values.licenseType | lower) "non-prod"  }}
      productName: "IBM Control Center Monitor Non-Prod Certified Container"
      productID: "6827a92f0c4447ad8685d9ef4107c949"
    {{- else }}
      productName: "IBM Control Center Monitor Certified Container"
      productID: "3a3896afa0df4d5db217ae67d055e77f"
    {{- end }}
      productVersion: "v6.4"
      productMetric: "VIRTUAL_PROCESSOR_CORE"
      productChargedContainers: "All"
    podSecurityContext:
      runAsNonRoot: true
      supplementalGroups: 
      {{- if .Values.storageSecurity.supplementalGroups }}
      {{- with .Values.storageSecurity.supplementalGroups }}
        {{ toYaml . | nindent 6 }}
      {{- end }}
      {{- else }}
      - 65534
      {{- end }}
      {{- if .Values.storageSecurity.fsGroup }}
      fsGroup: {{ .Values.storageSecurity.fsGroup }}
      {{- end }}
      fsGroupChangePolicy: {{ .Values.storageSecurity.fsGroupChangePolicy | default "OnRootMismatch" }}
      {{- if $runAsUser }}
      runAsUser: {{ $runAsUser }}
      {{- end }}
      #runAsGroup: 0
      seccompProfile:
        type: {{ .Values.secComp.type | quote }}
        {{- if ne .Values.secComp.type "RuntimeDefault" }}
        localhostProfile: {{ .Values.secComp.profile | quote }}
        {{- end }}
    initContainerSecurityContext:
      privileged: false
      {{- if $runAsUser }}
      runAsUser: {{ $runAsUser }}
      {{- end }}
      #runAsGroup: 0
      readOnlyRootFilesystem: false
      allowPrivilegeEscalation: false
      capabilities:
        drop: [ "ALL" ]
    containerSecurityContext:
      privileged: false
      {{- if $runAsUser }}
      runAsUser: {{ $runAsUser }}
      {{- end }}
      #runAsGroup: 0
      readOnlyRootFilesystem: false
      allowPrivilegeEscalation: false
      capabilities:
        drop: [ "ALL" ]
{{- end -}}
