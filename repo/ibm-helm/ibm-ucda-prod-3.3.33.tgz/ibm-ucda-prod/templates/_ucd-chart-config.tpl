{{/*
license  parameter must be set to true
*/}}
{{- define "{{ .Chart.Name }}.licenseValidate" -}}
  {{ $license := .Values.license.accept }}
  {{- if $license -}}
    true
  {{- end -}}
{{- end -}}

{{- define "{{ .Chart.Name }}.imagePath" -}}
{{- $imagePrefix := "" -}}
{{- if or (eq .Values.global.imageRegistry "cp.icr.io/cp") (not .Values.global.imageRegistry) -}}
  {{- printf "cp.icr.io/cp%s" $imagePrefix -}}
{{- else if .Values.global.imageRegistry -}}
  {{- .Values.global.imageRegistry | clean | trimSuffix "/" -}}
{{- end -}}
{{- end -}}

{{/* Determine which image to use given the product version.
   * Values.version can be an imagespec to allow registries other than IBM ER */}}
{{- define "{{ .Chart.Name }}.agentImageSpec" -}}
{{- $imagePathName := include "{{ .Chart.Name }}.imagePath" . | trim -}}
{{- if eq .Values.version "8.2.2.1" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:b02edfc37a265d566c576485c3a7be7ee72599381a1f783464cd37c32581cc8d
{{- else if eq .Values.version "8.2.2.0" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:766a5bbb69d9d99376138a7e322a3232be31a354d86b57132bebcb244e7883dc
{{- else if eq .Values.version "8.2.1.0" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:3f99830b9ffcfc0a5d2027619e21b75a60e2bac2a81d49c7ec29511a7d4208a5
{{- else if eq .Values.version "8.2.0.1" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:92f17c0231ac7178ecda671f3bd10e06242572c059b502bf6efdbc5a1669de20
{{- else if eq .Values.version "8.2.0.0" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:da8fad53bef978cdaa7ed8a565dde33fd37dc70273a5842eb4217775ce3d3faa
{{- else if eq .Values.version "8.1.2.8" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:ece0fb7ef49447c1dcd98e56dc5ea8feecc2c5f59ef564133407acad496534b7
{{- else if eq .Values.version "8.1.2.7" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:b11c82188e2a04b98e39fbcd830574e015b594a50482ac794ae0cc3b559aa922
{{- else if eq .Values.version "8.1.2.6" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:b417ffa7d6e9501fc6ce82926cfc43018d9208b8c4a15abbfc4fc264c0c84fde
{{- else if eq .Values.version "8.1.2.5" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:7b8459da2b38c4f11c3f3813e810aa17d4eabd412e72139652cf756819bfa102
{{- else if eq .Values.version "8.1.2.4" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:86e0055c670e68025502d22b861aab33a023d1172f6c3f2fa6d25b8e50e30b28
{{- else if eq .Values.version "8.1.2.3" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:971204546f064da267e46afefa1d2b072d29bb2ce1733bed546632fcc3baf6fe
{{- else if eq .Values.version "8.1.2.2" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:c974cebfa4cd663801048941a7da858232d1912628c500c2778fcc83710b583b
{{- else if eq .Values.version "8.1.2.1" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:4d44bc126f1e1c16f9e727dcbfa5f827a3d6b86ea335679cb3fdfd226397a00a
{{- else if eq .Values.version "8.1.2.0" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:9d19e7c2e4aa005e2b1096abd2d2347f536f12bccc1ca2e17eb0cc5e6ad4ecb8
{{- else if eq .Values.version "8.1.1.0" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:d9ef53f0653e182c847afb5bb3bcbaf1e8f788148e67e2d7baa6261ce3a8d7f6
{{- else if eq .Values.version "8.1.0.1" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:2e76fa49a4fa4bd35e212180be0a7200cf42d8f8d5fe56e6b2cee52b6356ca22
{{- else if eq .Values.version "8.1.0.0" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:2777d346c011fe2992185d4f128a9fa1470f1e859863601828e2843c770da83c
{{- else if eq .Values.version "8.0.1.15" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:619a3b433e4c8ff3c8a41ffe0952663e4464064a4addeef1e210a26fa63dd619
{{- else if eq .Values.version "8.0.1.14" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:1b3ffde91f60218a57abcd8b7ed59830f6bb13f10eba8a27fefdef6afa55e322
{{- else if eq .Values.version "8.0.1.13" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:12d7877a6fbd438a721d2815ca109707b7e89979c5b720a347cb79ec049fccc5
{{- else if eq .Values.version "8.0.1.12" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:e3ae76cc80f1aa7ccec8c7cbc03faab9d20042c8b1d042a9e0375b0c8397c708
{{- else if eq .Values.version "8.0.1.11" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:91266d71930159acb310cd480e16cadc5ef203cd6cd0ea20d448bc8fe8c0d8a4
{{- else if eq .Values.version "8.0.1.10" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:1dc19c516c5b01d063c8df82c9078a6c9450a9c24c2dc8376a373e377ccc984a
{{- else if eq .Values.version "8.0.1.9" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:8174f3ea8efc80f8f33607343533f9f0b6f9aef5a4152ebf56c2722eb76b4f11
{{- else if eq .Values.version "8.0.1.8" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:3441c303bf463a3d4bfbc09cb608901db3264b1468155c0dcf557c46b19e7f9a
{{- else if eq .Values.version "8.0.1.7" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:43f9b4d99a719ea66c03391e21bfb6e9e256cb2635a94462c338eb30184651f5
{{- else if eq .Values.version "8.0.1.6" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:6e61a1ccd555568b058a68fa801e3a0d18d7a61775b67dea77e3ed15b42f5adc
{{- else if eq .Values.version "8.0.1.5" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:35b9771d831b329d9b88b0203ce7f66567bdcfe5130d3e2b6ee214ea1cd52ce4
{{- else if eq .Values.version "8.0.1.4" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:c10adabca9ad40d13755771c4a4eda8f95a25009c42f4d7e580e0e1bc3d6f9c8
{{- else if eq .Values.version "8.0.1.3" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:16069ed7d6ee2c90a641fc1acf1b366eff084f8a34d4b9dd351fcf4ad157a91a
{{- else if eq .Values.version "8.0.1.2" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:bb57fbee54fc77cbc7fb87bd1fdfdcfc5796b4e5d295db00e7b0bde5562d97ba
{{- else if eq .Values.version "8.0.1.1" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:01ad7a8ab4c119c298a7700579b2467bb9d1c6f7f8c2af17b97cd663930b22f8
{{- else if eq .Values.version "8.0.1.0" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:e39f7a17558de69c79eb57a460e120d56400d4e7a3e95c7fb2876224f7497f6e
{{- else if eq .Values.version "8.0.0.1" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:46b43b0356d2da49a9cc3e6df7460bd054513476bc990b1ca10add924f196bb2
{{- else if eq .Values.version "8.0.0.0" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:c08816c74c87defd714fdae7d371c0c61fd8f83b70ee4bbdb1da389967aeac6e
{{- else if eq .Values.version "7.3.2.20" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:cb7a3e63ecd1aa2b90ff2f08cdce68724a5bc150918a9385a442871774f4edba
{{- else if eq .Values.version "7.3.2.19" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:58de0437a8560db58e120e3c30b7a375c98bde745700e878d05ccb9cdbda095b
{{- else if eq .Values.version "7.3.2.18" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:1bece36a7822ee6ab6d343ad0bfa079f8fb50e0f662c7b48896dd4bd748c3993
{{- else if eq .Values.version "7.3.2.17" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:90dffa1360b397bac60bf90a3ab760c8e6148c257c18c8e26d988ceaaf6e7def
{{- else if eq .Values.version "7.3.2.16" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:8222c58335903cf105c5e16a547f6f798ef641603a7a0acfa852091725c237f4
{{- else if eq .Values.version "7.3.2.15" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:f338d7583219f6a84bf59267be1d54ce5f848a6d9392eadada2a97fc298e5e03
{{- else if eq .Values.version "7.3.2.14" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:592c750b63c0e9f87a962ecc75beec6dcc7fd173763c080584b49cb7f4771000
{{- else if eq .Values.version "7.3.2.13" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:3f3fe22649d29504ff969aa16b238998a0da43ac92e424c7bccefd502e2d90ca
{{- else if eq .Values.version "7.3.2.12" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:af38c845f9d0940f01bd5856357bea5ebffe32447a0693147799407b4d7cb4ee
{{- else if eq .Values.version "7.3.2.11" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:1388c786fb12d7f6748878bcf7ba4d59612a222ec8abfe132fa95aad29549a4a
{{- else if eq .Values.version "7.3.2.10" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:cf01d58305b106c571246b1f1864dfb0d3a33fd3c9caa1d80c3b57aedab7a59f
{{- else if eq .Values.version "7.3.2.9" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:bb57fc7aaf1352fdafcc27b61a015644b6c92bbdb6c066cda444fbbdce205424
{{- else if eq .Values.version "7.3.2.8" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:303de8cda0d28456584344d670b70a300f9c361080d4504e5052535928b34ce1
{{- else if eq .Values.version "7.3.2.7" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:400f18512251486963ffd9dc70afc1b8551b11d58de9e2144981168df6af84c2
{{- else if eq .Values.version "7.3.2.6" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:82f2708c93087f521dd54cbabf7437a8a00b0277dd0466a38f41048366ab1a14
{{- else if eq .Values.version "7.3.2.5" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:978bb53a3f74508ba719b9ba20e39a2dd42afffa69ed518314b127f7d713d68d
{{- else if eq .Values.version "7.3.2.4" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:34cf32f8af22636e0a42bd9dcc5cb42c1d2cccfa8b99d9676971605b94e7db2d
{{- else if eq .Values.version "7.3.2.3" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:2a2257d6f6e1f740c59baa3a1deed4dc051c1b3078270acb5234bcd53575110b
{{- else if eq .Values.version "7.3.2.2" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:3082dda74b62e2078fb1f713ec9c6fb8d17c288cb38d985244101f7157d7f062
{{- else if eq .Values.version "7.3.2.1" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:079e016417bb08463d6dfba77e607a267e513659614f26411af9cbdb50076f6d
{{- else if eq .Values.version "7.3.2.0" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:83193cfddb653d82dbcce74ca05caa7cae60fdfd2cca72904a0afc232cc2ff6f
{{- else if eq .Values.version "7.3.1.1" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:150c0dbe81dd5b748f5d4948187eefc7ff71265b3fe1f7a87f0d1f5606eed6a4
{{- else if eq .Values.version "7.3.1.0" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:d47d186a8b96a60de38491fc4bb08f14c79a6399b840f97712fd631570572cae
{{- else if eq .Values.version "7.3.0.1" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:24af54f221f11e93b5abc9207d085c75f45a5551e947dc6b1c272ffff9128edb
{{- else if eq .Values.version "7.3.0.0" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:ed9ad59e0a4c31f9a08e3364bbfdb14bc3f4d88e49848df20369876e67521d89
{{- else if eq .Values.version "7.2.3.25" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:799d35f0e8daaf93c7c58dfc1d2284db11c7082b0358a277397282438baf4571
{{- else if eq .Values.version "7.2.3.24" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:152fd24fff7f828adec648bf7e66cd3d57f7f04dd1f047daa8f7acc9cbebf1b2
{{- else if eq .Values.version "7.2.3.23" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:f62463c5e4b724cda10d36e06489776e720a8d47337d66ca98b094bd7a77ce84
{{- else if eq .Values.version "7.2.3.22" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:819b8f0984a288170c52d7dbfd7211e742526f37cf4054e9570236371b0a45ba
{{- else if eq .Values.version "7.2.3.21" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:042076e2f02a43dd79991d9cfd9a10bfafc4d1e2c1b353f785e1af5a33d57d3a
{{- else if eq .Values.version "7.2.3.20" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:125b146a17bcef3e7004d54cc0ec817aa23fa8d74ea6fff20c2f2ee26538956c
{{- else if eq .Values.version "7.2.3.19" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:44800f2d9b9d621a165e5e9e5601e7cc79ff3db3ce4ec107d35a786d9ab89702
{{- else if eq .Values.version "7.2.3.18" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:6e30379f3fef3a41c3f6aeda926f7c01c9fec05453c3e407e32ea8b67795d50c
{{- else if eq .Values.version "7.2.3.17" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:64a912b9656bddaaf7c45ff5f2bdc8b5620d10e1e447d7c331001cfe4cfb5dfd
{{- else if eq .Values.version "7.2.3.16" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:41d8b81302c20264233acbf7908de794486eccce1a7eb2b84fd1253493cd0d21
{{- else if eq .Values.version "7.2.3.15" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:b2f1dd107373338ac2f98e096142ea6d41d8ec6e0641fe8b25348ae373f41b9c
{{- else if eq .Values.version "7.2.3.14" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:628f73dfcd4a351b51f7412a1a5a2a153a481aeb927a04a27aea3e3ecfae9ef2
{{- else if eq .Values.version "7.2.3.13" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:bc1cf7beb65d08056f6adc00170718243bf71bb1b03abb2e6540bd3b92df33a4
{{- else if eq .Values.version "7.2.3.12" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:5d68728f3dd5babc0208c1a9d49a87685bbbdb97b88df039dbc58887f61c0398
{{- else if eq .Values.version "7.2.3.11" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:9be5f9ba65299ae68088a9b82a5f91715b9ba241871daa2dec142ee960b49e46
{{- else if eq .Values.version "7.2.3.10" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:52decb9b13351edecf7f8d2f3f8be46dea93e1d472c43eed137c81370567973c
{{- else if eq .Values.version "7.2.3.9" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:82e37591d66e526d2ff29945f1c69da41d4a0cb7667c44dee06817354f907067
{{- else if eq .Values.version "7.2.3.8" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:2c90aa8381865fb40112d6d8b99bcc5168c3207583f5d370dd08e0abe88d6257
{{- else if eq .Values.version "7.2.3.7" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:00c828a8b878946d8214e05615532f3b9d27f168bf6a9b31683b41d56729797d
{{- else if eq .Values.version "7.2.3.6" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:f903a3d2d6046eced8fa1ea1884ea71dc05f62ecec579ce259bc93b6dff143d2
{{- else if eq .Values.version "7.2.3.5" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:74e7f95752669131fbb213ea2eaf15cbd528dfd450a0c8c4e3adc4053f157886
{{- else if eq .Values.version "7.2.3.4" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:48fade5f533d5b44e04223452d6d8da3bf270aed2905b72d54c5d4c786125688
{{- else if eq .Values.version "7.2.3.3" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:316546feb9a004cb6430f1d7ce136110587881654cc0263c9060c793e7529053
{{- else if eq .Values.version "7.2.3.2" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:3bc21f8419ede15403f6aae12960f8f3a582c746cbb6975576e4c955058ee2d4
{{- else if eq .Values.version "7.2.3.1" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:050f2a8df044a87c07758dd8218bef59114ccee7f0ad1aaae56db97e5c4b9944
{{- else if eq .Values.version "7.2.3.0" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:e1fa2b9e71432ce94bf7b55b60ba64e95abfaae35cd4812e1ac3f5b66be6e578
{{- else if eq .Values.version "7.2.2.1" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:6ce0ed9c560469983be172e9f9e8aaa5d32923b24ef031cf175bfebfb27ff6f4
{{- else if eq .Values.version "7.2.2.0" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:04b58b16d77ad6fa4117e361034d4cb7d2ccc5417ccfe77d9870adb4646c88fa
{{- else if eq .Values.version "7.2.1.2" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:0f70c7a15b76bebf0fa7211d196fd7243c2968bff8aeb23bb79e1e0f41273a43
{{- else if eq .Values.version "7.2.1.1" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:51fa7da8873c3dff180739c3180ff2f5e812fbbac8541c28cfcece1763a9fc31
{{- else if eq .Values.version "7.2.1.0" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:9251f7d9caacd3fadd3fe1fb2ee4a77413ac62083184fcccdaff14de95342e02
{{- else if eq .Values.version "7.2.0.2" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:645a21a9668d0cb1b50e5514208224ee193215a6ae46a1f6475c52ec93101da1
{{- else if eq .Values.version "7.2.0.1" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:8ae16aabe832e0cd0ac9a671636bff82cfe6bdb69fedfdc85cc01e03863f61f6
{{- else if eq .Values.version "7.2.0.0" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:c26cc9113198194ac4ed59c456652c4bf98f795e8d699a57d22e28f3a81a3c99
{{- else if eq .Values.version "7.1.2.30" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:65a140547fa7f0b26e52d2b6d52d1578284699282d1bee487b53322d3e3b66d6
{{- else if eq .Values.version "7.1.2.29" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:e202cd8dec152204a3af05e44cde9f93b5fd399d99c7c02c2fdfebe4ebee8182
{{- else if eq .Values.version "7.1.2.28" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:a000ab43075e4c6e21f8eaa20685380670df9c6b11b9e605f98fa2df13c34476
{{- else if eq .Values.version "7.1.2.27" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:f4c1ab59b3a39595637562035bd6fee0cf1a0c47bdb5ace66074b84bc871f443
{{- else if eq .Values.version "7.1.2.26" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:24e441d6ee76af69fa558040ee9416674d147c9c1790f8fa29c6865b793b9228
{{- else if eq .Values.version "7.1.2.25" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:0b3afc54472701ffd8ef61348b75d7fc5fb2e64cd0e283fcaa41872ef628397c
{{- else if eq .Values.version "7.1.2.24" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:dddfbbcbbf5d03096bad970054352acdcf57e07cb45a44b577a9ae1b58e3ea4d
{{- else if eq .Values.version "7.1.2.23" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:93294653c9ee458a0cf9a131c2d092bab1384a233c6bd621ea5f908b3c3e249b
{{- else if eq .Values.version "7.1.2.22" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:c4cd91234e49af228e269ea6725621ae2783d772267b6b2ee5c4b273bb2546ad
{{- else if eq .Values.version "7.1.2.21" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:52cf313108abea91a5236bbd5932b5965c08c04e39e75bf341332119ef216f94
{{- else if eq .Values.version "7.1.2.20" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:d021eec744310be953b6b5e6965c5560c59545ba5a8ba0a426054eac8f588df5
{{- else if eq .Values.version "7.1.2.19" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:04d4ab2564210869f607f3b3866785e2340b0dd1b591f838c67d1ea9d966bd56
{{- else if eq .Values.version "7.1.2.18" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:f39d6fa183ae29fa7b67f39c4674ff2881924d2b5f34bd0da562a2ae9a1f628a
{{- else if eq .Values.version "7.1.2.17" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:049828fe785d3de52574590b15e6c9736a782779762b336574070fc7211ccded
{{- else if eq .Values.version "7.1.2.16" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:781a3d0a0341ef554dedc3e81e7f1b614cd46ce291f7b7690e9b27dd37f83d80
{{- else if eq .Values.version "7.1.2.15" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:cd2192ec0d8dd89c205a33bbbaeec59c7ae3f632b4373398222902205fa15571
{{- else if eq .Values.version "7.1.2.14" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:dbbe8d13f15ada9a4d2b35fb594bca4e4e76c16b717b55a0f865456472ec4424
{{- else if eq .Values.version "7.1.2.13" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:36b23d311814197084b8bfe1504ef2b782aae41afcff2e5e6097498d8188e541
{{- else if eq .Values.version "7.1.2.12" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:e8274ad04228653462eed5c2106a03e956d8daad7226ec1734b7762ff1f1ad2e
{{- else if eq .Values.version "7.1.2.11" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:be365161ebe0f88d292b24b0c17e7fb745e3d23dc13b75d5d87a031f90f3b22c
{{- else if eq .Values.version "7.1.2.10" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:92d20099e84f3a4b7493f441249ab41a17717c22fb8e9556e80872769a82e6b9
{{- else if eq .Values.version "7.1.2.9" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:0d1392a43b51a4cadd761c828d02c1098deea84992478a323aa84848099d6351
{{- else if eq .Values.version "7.1.2.8" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:0bb8b063121084412a0ded9a564f44dde5da71405be235ffebdc4607b06c2749
{{- else if eq .Values.version "7.1.2.7" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:78743547c069f3d3e6cc46778446209de6abac59f9b5c6bcf4755c86497d91f6
{{- else if eq .Values.version "7.1.2.6" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:da73a3b4a6244f1e515b1a689769b1f8d1c8595c34e0212122b5f6667c8dc730
{{- else if eq .Values.version "7.1.2.5" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:5421141aa2bc52acdfc920492f692fb0aba343feaf49b04c28a9916048f3698c
{{- else if eq .Values.version "7.1.2.1" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:76ddedef53b5b5f6f5f72d1f14068967b133b04ad4018df014b1228f5eb259a3
{{- else if eq .Values.version "7.1.2.0" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:366642772a2e84decfcbeda42745494f23a494d24248f838a00e8f2139a122d8
{{- else if eq .Values.version "7.1.1.2" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:0bf58dc592ca7127fec75148df8ba92f29a55e072c6b056e534ab1ab0695709c
{{- else if eq .Values.version "7.1.1.1" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:8a3c5815cdfc7852a74fb62ba5c4a954246a17a6947cefc561f29de2181081ae
{{- else if eq .Values.version "7.1.1.0" -}}
  {{ $imagePathName }}/ibm-ucda@sha256:6b34cf4a0ce9b2f6398ea2bb41e8d614bba7befe8f5cbdce6d06d78c9207042d
{{- else if eq .Values.version "7.1.0.3" -}}
  {{ $imagePathName }}/ibm-ucda:7.1.0.3.1069281
{{- else -}}
  {{ .Values.version }}
{{- end -}}
{{- end -}}
