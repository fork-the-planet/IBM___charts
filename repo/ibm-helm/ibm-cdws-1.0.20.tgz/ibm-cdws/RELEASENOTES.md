# Prerequisites

Please refer prerequisites section from [README.md](README.md)

# Documentation

Please refer to [README.md](README.md) provided with chart for detailed installation instruction.

# Version History

| Chart | Date         | Kubernetes Required | OpenShift Required       | Image(s) Supported                                    | Details            |
| ----- | ------------ | ------------------- | ------------------------ | ----------------------------------------------------- | ------------------ | 
| 1.0.0 | Mar 28, 2024 | >= 1.27.0 <1.28.0   | = 4.14                   | cdws6.3_certified_container_6.3.0.7:6.3.0.7_ifix000   | CDWS 6.3.0.7       |
| 1.0.1 | Jun 07, 2024 | >= 1.27.0 <1.28.0   | = 4.14                   | cdws6.3_certified_container_6.3.0.8:6.3.0.8_ifix000   | CDWS 6.3.0.8       |
| 1.0.2 | Aug 04, 2024 | >= 1.27.0 <1.30.0   | >= 4.14 <= 4.16          | cdws6.3_certified_container_6.3.0.9:6.3.0.9_ifix000   | CDWS 6.3.0.9       |
| 1.0.3 | Oct 04, 2024 | >= 1.27.0 <1.30.0   | >= 4.14 <= 4.16          | cdws6.3_certified_container_6.3.0.10:6.3.0.10_ifix000 | CDWS 6.3.0.10      |
| 1.0.4 | Nov 19, 2024 | >= 1.27.0 < 1.30.0  | >= 4.14 <= 4.16          | cdws6.3_certified_container_6.3.0.11:6.3.0.11_ifix000 | CDWS 6.3.0.11      |
| 1.0.5 | Dec 13, 2024 | >= 1.27.0 < 1.31.0  | >= 4.14 <= 4.17          | cdws6.3_certified_container_6.3.0.11:6.3.0.11_ifix001 | CDWS 6.3.0.11      |
| 1.0.6 | Jan 09, 2025 | >= 1.27.0 < 1.31.0  | >= 4.14 <= 4.17          | cdws6.3_certified_container_6.3.0.11:6.3.0.11_ifix002 | CDWS 6.3.0.11      |
| 1.0.7 | Feb 27, 2025 | >= 1.27.0 < 1.31.0  | >= 4.14 <= 4.17          | cdws6.3_certified_container_6.3.0.12:6.3.0.12_ifix000 | CDWS 6.3.0.12      |
| 1.0.8 | Apr 22, 2025 | >= 1.27.0 < 1.32.0  | >= 4.14 <= 4.17          | cdws6.3_certified_container_6.3.0.13:6.3.0.13_ifix000 | CDWS 6.3.0.13      |
| 1.0.9 | May 21, 2025 | >= 1.27.0 < 1.32.0  | >= 4.14 <= 4.17          | cdws6.3_certified_container_6.3.0.13:6.3.0.13_ifix001 | CDWS 6.3.0.13      |
| 1.0.10| Jun 25, 2025 | >= 1.27.0 < 1.32.0  | >= 4.14 <= 4.18          | cdws6.3_certified_container_6.3.0.14:6.3.0.14_ifix000 | CDWS 6.3.0.14      |
| 1.0.11| Jul 16, 2025 | >= 1.27.0 < 1.32.0  | >= 4.14 <= 4.18          | cdws6.3_certified_container_6.3.0.14:6.3.0.14_ifix001 | CDWS 6.3.0.14      |
| 1.0.12| Jul 28, 2025 | >= 1.27.0 < 1.32.0  | >= 4.14 <= 4.18          | cdws6.3_certified_container_6.3.0.14:6.3.0.14_ifix002 | CDWS 6.3.0.14      |
| 1.0.13| Oct 01, 2025 | >= 1.27.0 < 1.33.0  | >= 4.14 <= 4.19          | cdws6.3_certified_container_6.3.0.15:6.3.0.15_ifix000 | CDWS 6.3.0.15      |
| 1.0.14| Dec 09, 2025 | >= 1.27.0 < 1.34.0  | >= 4.14 <= 4.19          | cdws:6.3.0.16_iFix00-2025-11-27                       | CDWS 6.3.0.16      |
| 1.0.15| Feb 06, 2026 | >= 1.27.0 < 1.34.0  | >= 4.14 <= 4.19          | cdws:6.3.0.17_iFix00-2026-02-06                       | CDWS 6.3.0.17      |
| 1.0.16| Apr 10, 2026 | >= 1.27.0           | >= 4.14 <= 4.19          | cdws:6.3.0.18_iFix00-2026-04-10                       | CDWS 6.3.0.18      |
| 1.0.17| Apr 15, 2026 | >= 1.27.0           | >= 4.14 <= 4.19          | cdws:6.3.0.18_iFix00-2026-04-10                       | CDWS 6.3.0.18      |
| 1.0.18| May 28, 2026 | >= 1.27.0           | >= 4.14 <= 4.19          | cdws:6.3.0.19_iFix00-2026-05-28                       | CDWS 6.3.0.19      |
| 1.0.19| Jun 22, 2026 | >= 1.27.0           | >= 4.14 <= 4.19          | cdws:6.3.0.19_iFix01-2026-06-22                       | CDWS 6.3.0.19      |
| 1.0.20| Jul 13, 2026 | >= 1.27.0           | >= 4.14 <= 4.19          | cdws:6.3.0.20_iFix00-2026-07-10                       | CDWS 6.3.0.20      |

`Note: The images listed here are minimum supported container image for the respective helm chart version.`
