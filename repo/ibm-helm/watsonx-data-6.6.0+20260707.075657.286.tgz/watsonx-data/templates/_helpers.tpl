{{- define "watsonx-data.rbac" -}}
- apiGroups:
    - ''
  resources:
    - configmaps
    - endpoints
    - secrets
    - serviceaccounts
    - pods
    - pods/attach
    - pods/exec
    - persistentvolumeclaims
    - services
  verbs:
    - create
    - delete
    - deletecollection
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - ''
  resources:
    - bindings
    - events
  verbs:
    - get
    - list
    - watch
{{- if and (hasKey .Values.watsonxData "enableEvents") (eq .Values.watsonxData.enableEvents false)  }}
# create events permission has been disabled
{{- else if and (hasKey .Values "watsonxDataPremium") (hasKey .Values.watsonxDataPremium "enableEvents") (eq .Values.watsonxDataPremium.enableEvents false)  }}
# create events permission has been disabled
{{- else }}
- apiGroups:
  - coordination.k8s.io
  resources:
  - leases
  verbs:
  - get
  - list
  - watch
  - create
  - update
  - patch
  - delete
- apiGroups:
    - ''
  resources:
    - events
  verbs:
    - create
    - patch
{{- end }}
- apiGroups:
    - ''
  resources:
    - services/status
    - pods/log
    - pods/status
    - persistentvolumeclaims/status
  verbs:
    - get
    - list
    - watch
- apiGroups:
    - apps
  resources:
    - deployments
    - deployments/scale
    - statefulsets
    - statefulsets/scale
  verbs:
    - get
    - list
    - create
    - delete
    - deletecollection
    - patch
    - update
    - watch
- apiGroups:
    - apps
  resources:
    - deployments/status
    - statefulsets/status
  verbs:
    - get
    - list
    - watch
- apiGroups:
    - autoscaling
  resources:
    - horizontalpodautoscalers
  verbs:
    - get
    - list
    - create
    - delete
    - deletecollection
    - patch
    - update
    - watch
- apiGroups:
    - autoscaling
  resources:
    - horizontalpodautoscalers/status
  verbs:
    - get
    - list
    - watch
- apiGroups:
    - batch
  resources:
    - cronjobs
    - jobs
  verbs:
    - get
    - list
    - create
    - delete
    - deletecollection
    - patch
    - update
    - watch
- apiGroups:
    - batch
  resources:
    - cronjobs/status
    - jobs/status
  verbs:
    - get
    - list
    - watch
- apiGroups:
    - rbac.authorization.k8s.io
  resources:
    - roles
    - rolebindings
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
{{- if and (hasKey .Values.watsonxData "enableRoutes") (eq .Values.watsonxData.enableRoutes false)  }}
# route permission has been disabled
{{- else if and (hasKey .Values "watsonxDataPremium") (hasKey .Values.watsonxDataPremium "enableRoutes") (eq .Values.watsonxDataPremium.enableRoutes false)  }}
# route permission has been disabled
{{- else }}
- apiGroups:
    - route.openshift.io
  resources:
    - routes
  verbs:
    - create
    - delete
    - deletecollection
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - route.openshift.io
  resources:
    - routes/custom-host
    - routes/custom-tls
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
{{- end }}
{{- if and (hasKey .Values.watsonxData "enableNetworkpolicies") (eq .Values.watsonxData.enableNetworkpolicies false)  }}
# network policy permission has been disabled
{{- else if and (hasKey .Values "watsonxDataPremium") (hasKey .Values.watsonxDataPremium "enableNetworkpolicies") (eq .Values.watsonxDataPremium.enableNetworkpolicies false)  }}
# network policy permission has been disabled
{{- else }}
- apiGroups:
    - networking.k8s.io
  resources:
    - networkpolicies
  verbs:
    - create
    - delete
    - deletecollection
    - get
    - list
    - patch
    - update
    - watch
{{- end }}
- apiGroups:
    - watsonxdata.ibm.com
  resources:
    - wxds
    - wxds/status
    - wxds/finalizers
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - watsonxdata.ibm.com
  resources:
    - wxdaddons
    - wxdaddons/status
    - wxdaddons/finalizers
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - watsonxdata.ibm.com
  resources:
    - wxdaddonpremiums
    - wxdaddonpremiums/status
    - wxdaddonpremiums/finalizers
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - watsonxdata.ibm.com
  resources:
    - wxdengines
    - wxdengines/status
    - wxdengines/finalizers
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - zen.cpd.ibm.com
  resources:
    - zenextensions
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - zen.cpd.ibm.com
  resources:
    - zenextensions/status
  verbs:
    - get
- apiGroups:
    - zen.cpd.ibm.com
  resources:
    - zenservices
    - zenservices/status
  verbs:
    - get
    - list
    - watch
- apiGroups:
    - postgresql.k8s.enterprisedb.io
  resources:
    - clusters
    - backups
  verbs:
    - get
    - create
    - delete
    - update
    - patch
    - list
    - watch
- apiGroups:
    - cert-manager.io
  resources:
    - certificates
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - operator.ibm.com
  resources:
    - ibmlicensingdefinitions
  verbs:
    - create
    - get
    - list
    - watch
    - patch
    - update
    - delete
- apiGroups:
    - db2u.databases.ibm.com
  resources:
    - db2uinstances
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - db2u.databases.ibm.com
  resources:
    - db2uinstances/status
  verbs:
    - get
- apiGroups:
    - ae.cpd.ibm.com
  resources:
    - analyticsengines
    - analyticsengines/status
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - ccs.cpd.ibm.com
  resources:
    - ccs
    - ccs/status
    - ccs/finalizers
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - elasticsearch.opencontent.ibm.com
  resources:
    - elasticsearchclusters
    - elasticsearchclusters/spec
    - elasticsearchclusters/status
    - elasticsearchclusters/finalizers
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - datarefinery.cpd.ibm.com
  resources:
    - datarefinery
    - datarefinery/spec
    - datarefinery/status
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - wml.cpd.ibm.com
  resources:
    - wmlbase
    - wmlbases
    - wmlbase/spec
    - wmlbase/status
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - ikc.cpd.ibm.com
  resources:
    - ikcstandard
    - ikcstandard/spec
    - ikcstandard/status
    - ikcpremium
    - ikcpremium/spec
    - ikcpremium/status
    - semanticautomation
    - semanticautomation/spec
    - semanticautomation/status
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - ws.cpd.ibm.com
  resources:
    - ws
    - ws/spec
    - ws/status
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - cpd.ibm.com
  resources:
    - datasift
    - datasift/status
    - datasift/finalizers
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - watsonxaiifm.cpd.ibm.com
  resources:
    - watsonxaiifm
    - watsonxaiifm/spec
    - watsonxaiifm/status
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - cpd.ibm.com
  resources:
    - watsonxdataintelligence
    - watsonxdataintelligence/status
    - watsonxdataintelligence/finalizers
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - missioncontrol.datastax.com
  resources:
    - missioncontrolclusters
  verbs:
    - create
    - delete
    - get
    - list
    - patch
    - update
    - watch
- apiGroups:
    - missioncontrol.datastax.com
  resources:
    - missioncontrolclusters/finalizers
  verbs:
    - update
- apiGroups:
    - missioncontrol.datastax.com
  resources:
    - missioncontrolclusters/status
  verbs:
    - get
    - patch
    - update
{{- end -}}
