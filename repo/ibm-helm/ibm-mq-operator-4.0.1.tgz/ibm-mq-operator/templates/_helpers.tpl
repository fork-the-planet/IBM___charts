{{/*
IBM MQ Operator Image
*/}}
{{- define "ibm-mq-operator.image" -}}
{{- if .Values.operator.deployment.sha -}}
{{ default "icr.io" .Values.privateRegistry }}/{{ .Values.operator.deployment.repository }}@{{ .Values.operator.deployment.sha }}
{{- else if .Values.operator.deployment.tag -}}
{{ default "icr.io" .Values.privateRegistry }}/{{ .Values.operator.deployment.repository }}:{{ .Values.operator.deployment.tag }}
{{- else -}}
{{- fail "One of .Values.operator.deployment.tag or .Values.operator.deployment.sha is required" }}
{{- end -}}
{{- end -}}

{{/*
IBM MQ Operator Queue Manager Env Vars
*/}}
{{ define "ibm-mq-operator.qm-envs" -}}
{{ $.Files.Get "static/image-digests-mq.yaml"
  | replace "value: cp.icr.io/cp/ibm-mqadvanced-server-integration" (print "value: " (default "cp.icr.io" .Values.privateRegistry) "/" .Values.operand.repositories.integration)
  | replace "value: cp.icr.io/cp/ibm-mqadvanced-server" (print "value: " (default "cp.icr.io" .Values.privateRegistry) "/" .Values.operand.repositories.production)
  | replace "value: icr.io/ibm-messaging/mq" (print "value: " (default "icr.io" .Values.privateRegistry) "/" .Values.operand.repositories.developer)
}}
{{- end }}
